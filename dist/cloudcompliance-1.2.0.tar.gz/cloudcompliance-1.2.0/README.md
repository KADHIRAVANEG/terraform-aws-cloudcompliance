[![Docker](https://img.shields.io/badge/Docker-ghcr.io-2496ED?logo=docker)](https://github.com/KADHIRAVANEG/terraform-aws-cloudcompliance/pkgs/container/terraform-aws-cloudcompliance)
[![PyPI version](https://img.shields.io/pypi/v/cloudcompliance?color=blue)](https://pypi.org/project/cloudcompliance/)
[![PyPI downloads](https://img.shields.io/pypi/dm/cloudcompliance)](https://pypi.org/project/cloudcompliance/)
[![Terraform Registry](https://img.shields.io/badge/Terraform%20Registry-cloudcompliance-7B42BC?logo=terraform)](https://registry.terraform.io/modules/KADHIRAVANEG/cloudcompliance/aws/latest)
![SOC2 Compliance](https://github.com/KADHIRAVANEG/Cloud-Compliance/actions/workflows/compliance.yml/badge.svg)
![Terraform](https://img.shields.io/badge/Terraform-1.15.6-7B42BC?logo=terraform)
![LocalStack](https://img.shields.io/badge/LocalStack-3.4.0-000000?logo=amazon-aws)
![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python)
![License](https://img.shields.io/badge/License-MIT-green)

# CloudCompliance — SOC2-Ready AWS IaC

> Infrastructure as Code that provisions a SOC2-aligned AWS security baseline
> in one command. Zero manual security configuration required.
> with 10 controls and 46 AWS resources — deployable in one command.

## The Problem

Startups spend 6–12 months retrofitting SOC2 controls onto infrastructure that
was never designed to be compliant. Security is an afterthought — CloudTrail
gets enabled after an incident, encryption gets added before an audit, RBAC
gets tightened only when required.

**This IaC eliminates that retrofit entirely.**
Every SOC2 control is provisioned automatically at infrastructure creation time.

---

## SOC2 Control Coverage

| Control | Title | Resources Enforced |
|---------|-------|--------------------|
| CC6.1 | Network Isolation | VPC, private subnets, deny-all security group |
| CC6.2 | Authentication Controls | IAM password policy, MFA alert, least-privilege role |
| CC6.3 | Access Revocation | IAM role policies, access analyzer alarms |
| CC6.6 | Transmission Protection | HTTPS-only S3 bucket policy, TLS enforcement |
| CC6.7 | Encryption at Rest | KMS CMK, S3 server-side encryption |
| CC7.1 | Threat Detection | CloudWatch alarms, AWS Config recorder + rules |
| CC7.2 | Audit Logging | Versioned audit bucket, VPC flow logs, Config delivery |
| CC7.3 | Incident Response | Log metric filters, unauthorized API call detection |
| CC8.1 | Change Management | IaC-controlled infra, Config recorder status |
| A1.1 | Availability | S3 versioning, retention policies, backup role |


> **Scope note:** This IaC implements the *technical infrastructure controls* 
> mapped to SOC2 Common Criteria CC6-CC8. Full SOC2 Type II certification 
> additionally requires organizational policies, vendor management, employee 
> training, and 6-12 months of evidence collection — which are outside the 
> scope of infrastructure code.

---

## What Gets Provisioned (46 resources across 9 modules)

### Networking — CC6.1
- Private VPC (`10.0.0.0/16`) with 2 private subnets
- No public subnets — zero internet exposure by default
- Default-deny security group
- VPC Flow Logs → CloudWatch (90-day retention)

### Logging — CC7.2
- Dedicated audit S3 bucket with versioning
- Delete protection + HTTPS-only policy
- AWS Config delivery channel

### Encryption — CC6.7
- KMS Customer Managed Key with automatic rotation
- S3 encrypted data bucket with KMS SSE
- HTTPS-only bucket policy

### IAM — CC6.2 + CC6.3
- Password policy: 14 chars, complexity, 90-day rotation
- Least-privilege IAM role — S3 read + KMS decrypt only
- Access analyzer role + findings alarm
- SNS topic for root account alerts

### Monitoring — CC7.1
- CloudWatch alarms: root login, public bucket detection
- AWS Config recorder — all resource types
- Config rules: S3 public read prohibited, S3 encryption required, root MFA

### Incident Response — CC7.3
- CloudWatch log group for security events (365-day retention)
- Log metric filters: unauthorized API calls, console sign-in failures
- CloudWatch alarms wired to SNS for both filters

### Availability — A1.1
- Versioned availability logs bucket
- Public access blocked
- Backup IAM role

### Config — CC7.1 + CC7.2
- AWS Config recorder + delivery channel
- 3 managed Config rules

### Change Management — CC8.1
- All resources IaC-controlled via Terraform
- Config recorder status tracking
- CI/CD gate on every PR

---

## Quick Start

**Requirements:** Terraform ≥ 1.15, Docker

```bash
# 1. Start LocalStack (free local AWS)
docker run --rm -d -p 4566:4566 localstack/localstack:3.4.0

# 2. Deploy all SOC2 controls
make deploy

# 3. Generate compliance evidence report
make report
```
## Use as a Terraform Module

```hcl
module "soc2_baseline" {
  source  = "KADHIRAVANEG/cloudcompliance/aws"
  version = "1.0.0"

  project_name = "my-startup"
  environment  = "prod"
  aws_region   = "us-east-1"
}
```

```bash
terraform init
terraform apply
```
## Install the CLI

```bash
pip install cloudcompliance
cloudcompliance
```

## Docker Usage

```bash
# Pull the image
docker pull ghcr.io/kadhiravaneg/terraform-aws-cloudcompliance:latest

# Run against your terraform state
docker run -v /path/to/your/terraform:/app/terraform \
  ghcr.io/kadhiravaneg/terraform-aws-cloudcompliance:latest

# Run against this repo's state
docker run -v ~/cloudcompliance/terraform:/app/terraform \
  ghcr.io/kadhiravaneg/terraform-aws-cloudcompliance:latest
```


**Expected output:**

```
╭────────────────────────────────────────╮
│ CloudCompliance — SOC2 Evidence Report │
│ Total resources provisioned: 29        │
╰────────────────────────────────────────╯
SOC2 Compliance Score: 100% (7/7 controls passing)
```

---

## Project Structure

```
cloudcompliance/
├── terraform/
│   ├── main.tf                  # Root — calls all modules
│   ├── variables.tf             # Environment, region, endpoint
│   ├── backend.tf               # Local (dev) / S3 (prod) backend
│   ├── local.tfvars             # LocalStack config
│   ├── prod.tfvars              # Real AWS config
│   └── modules/
│       ├── networking/          # CC6.1 — VPC, subnets, SGs
│       ├── logging/             # CC7.2 — Audit bucket
│       ├── encryption/          # CC6.7 — KMS, encrypted S3
│       ├── iam/                 # CC6.2 — Password policy, roles
│       ├── monitoring/          # CC7.1 — CloudWatch alarms
│       └── config/              # CC7.1/7.2 — Config rules
├── compliance/
│   └── report.py                # SOC2 evidence generator
├── .github/workflows/
│   └── compliance.yml           # CI gate — blocks non-compliant PRs
└── Makefile                     # make deploy / report / destroy
```

## Chart 

```mermaid
flowchart TD
    %% Styling Definitions
    classDef infra fill:#2980b9,stroke:#fff,color:#fff;
    classDef module fill:#34495e,stroke:#fff,color:#fff;
    classDef glue fill:#f39c12,stroke:#000,color:#000;
    classDef comp fill:#27ae60,stroke:#fff,color:#fff;

    %% Orchestration Layer
    MK[Makefile]:::glue
    CI[.github/workflows/compliance.yml]:::glue

    %% Terraform Root
    TF_Root[terraform/]:::infra
    TF_Root --> Main[main.tf]
    TF_Root --> Vars[vars/backend.tf]
    TF_Root --> TFVars[*.tfvars]

    %% Module Layer
    TF_Root --> Mod[modules/]:::module
    Mod --> N[networking - CC6.1]:::module
    Mod --> L[logging - CC7.2]:::module
    Mod --> E[encryption - CC6.7]:::module
    Mod --> I[iam - CC6.2]:::module
    Mod --> M[monitoring - CC7.1]:::module
    Mod --> C[config - CC7.1/7.2]:::module

    %% Compliance Evidence Layer
    Comp[compliance/report.py]:::comp

    %% Connections
    MK -->|deploy| TF_Root
    MK -->|report| Comp
    CI -->|gate| TF_Root
    CI -->|audit| Comp
```

---

## CI/CD Pipeline

Every pull request automatically runs:

1. **Terraform Validate** — format + syntax check
2. **Checkov Security Scan** — static analysis against 500+ security rules
3. **SOC2 Compliance Check** — deploys to LocalStack, runs report, blocks if score < 100%

---

## Deploying to Real AWS

```bash
# 1. Configure AWS credentials
aws configure

# 2. Deploy to real AWS
make deploy-prod
```

For production, uncomment the S3 backend in `terraform/backend.tf`
to enable remote state with DynamoDB locking.

---

## LocalStack vs Real AWS

| Feature              | LocalStack (free) | Real AWS |
|----------------------|-------------------|----------|
| VPC / Subnets        | ✅                | ✅       |
| S3 + Encryption      | ✅                | ✅       |
| KMS                  | ✅                | ✅       |
| IAM                  | ✅                | ✅       |
| CloudWatch           | ✅                | ✅       |
| AWS Config           | ✅                | ✅       |
| SNS                  | ✅                | ✅       |
| CloudTrail           | ⚠️ Pro only       | ✅       |
| GuardDuty            | ⚠️ Pro only       | ✅       |

---

> **Honest scope:** This IaC implements the *technical infrastructure controls*
> for SOC2 Common Criteria CC6–CC8 and Availability A1. Full SOC2 Type II
> certification additionally requires organizational policies, vendor management,
> employee training, and 6–12 months of evidence collection — which are outside
> the scope of any IaC tool.

## Standards Referenced

- [AICPA SOC2 Trust Services Criteria 2017](https://www.aicpa.org/resources/landing/system-and-organization-controls-soc-suite-of-services)
- [CIS AWS Foundations Benchmark v2.0](https://www.cisecurity.org/benchmark/amazon_web_services)
- [NIST SP 800-53 Rev 5](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-53r5.pdf)
- [AWS Security Reference Architecture](https://docs.aws.amazon.com/prescriptive-guidance/latest/security-reference-architecture/welcome.html)

---

## Tech Stack

`Terraform` · `Python` · `AWS` · `LocalStack` · `GitHub Actions` · `KMS` · `IAM` · `CloudWatch` · `SNS` · `AWS Config`

---

## Author

**Kadhiravan E.G.** — 3rd year Cybersecurity student  
GitHub: [@KADHIRAVANEG](https://github.com/KADHIRAVANEG)
